// 케이스 데이터 타입 정의
// 클라이언트와 서버에서 공통으로 참조하는 데이터 구조

export type CaseStatus = '진행중' | '감정서 제출' | '완료' | '보류';

export interface Case {
  id: string;
  case_no: string;
  court: string | null;
  bench: string | null;
  type: string | null;
  status: CaseStatus;
  fee: number | null;
  start_date: string | null;     // YYYY-MM-DD
  end_date: string | null;
  issue: string | null;
  result: string | null;
  notes: string | null;
  created_at: number;             // Unix epoch ms
  updated_at: number;
}

// 신규 등록 시 클라이언트가 보내는 형식 (id/타임스탬프 제외)
export type CaseInput = Omit<Case, 'id' | 'created_at' | 'updated_at'>;

// 부분 수정 시 형식
export type CaseUpdate = Partial<CaseInput>;


export interface CaseDocument {
  id: string;
  case_id: string;
  filename: string;
  stored_path: string;
  doc_type: string | null;        // 감정신청서/감정서/판결문/사진/도면/기타
  size_bytes: number | null;
  mime_type: string | null;
  notes: string | null;
  uploaded_at: number;
}


export interface CaseEvent {
  id: string;
  case_id: string;
  event_date: string;             // YYYY-MM-DD
  event_type: string | null;
  description: string | null;
  created_at: number;
}
