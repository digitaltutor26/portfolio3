import express from 'express';
import cors from 'cors';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { casesRouter } from './routes/cases.js';
import { docsRouter } from './routes/docs.js';
import './db.js';   // DB 초기화 (import만 해도 실행됨)

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const CLIENT_DIR = path.join(PROJECT_ROOT, 'client');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(cors());                     // 개발 편의를 위해 모든 출처 허용
app.use(express.json({ limit: '5mb' }));

// 헬스체크
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// API 라우트
app.use('/api/cases', casesRouter);
app.use('/api', docsRouter);          // /api/cases/:caseId/documents, /api/documents/:docId/...

// 정적 클라이언트 서빙
app.use(express.static(CLIENT_DIR));

// SPA fallback: 클라이언트 라우팅 시 index.html
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(CLIENT_DIR, 'index.html'));
});

// 0.0.0.0 바인딩 → Tailscale 등 같은 네트워크 디바이스에서도 접속 가능
app.listen(PORT, '0.0.0.0', () => {
  console.log(`[server] listening on http://localhost:${PORT}`);
  console.log(`[server] external (Tailscale 등): http://<this-machine-ip>:${PORT}`);
});
