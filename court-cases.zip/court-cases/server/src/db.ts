import Database from 'better-sqlite3';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// 프로젝트 루트 기준 경로
const PROJECT_ROOT = path.resolve(__dirname, '..', '..');
const DB_DIR  = path.join(PROJECT_ROOT, 'db');
const DB_PATH = path.join(DB_DIR, 'cases.db');
const SCHEMA_PATH = path.join(PROJECT_ROOT, 'scripts', 'schema.sql');

// db 폴더 자동 생성
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

export const db = new Database(DB_PATH);

// SQLite 권장 설정
db.pragma('journal_mode = WAL');     // 동시 읽기/쓰기 성능 향상
db.pragma('foreign_keys = ON');       // 외래키 제약 활성화

// 스키마 적용 (CREATE TABLE IF NOT EXISTS이라 매번 안전하게 실행 가능)
const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
db.exec(schema);

console.log(`[db] connected: ${DB_PATH}`);

// UUID 대용 ID 생성기
export function generateId(prefix: string = 'c'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

// 프로세스 종료 시 DB 안전하게 닫기
process.on('exit', () => db.close());
process.on('SIGINT', () => { db.close(); process.exit(0); });
process.on('SIGTERM', () => { db.close(); process.exit(0); });
