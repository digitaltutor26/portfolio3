import { Router, Request, Response } from 'express';
import { db, generateId } from '../db.js';
import type { Case, CaseInput, CaseUpdate } from '../types.js';

export const casesRouter = Router();

// 헬퍼: 빈 문자열은 null로 (UI에서 안 채우고 보낼 때 깔끔하게 저장)
function nullIfEmpty(v: unknown): string | null {
  if (v === null || v === undefined) return null;
  if (typeof v === 'string' && v.trim() === '') return null;
  return v as string;
}

function toNumberOrNull(v: unknown): number | null {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return isNaN(n) ? null : n;
}


// GET /api/cases - 검색·필터 지원
casesRouter.get('/', (req: Request, res: Response) => {
  const { q, status, type } = req.query;

  let sql = 'SELECT * FROM cases WHERE 1=1';
  const params: unknown[] = [];

  if (typeof status === 'string' && status) {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (typeof type === 'string' && type) {
    sql += ' AND type = ?';
    params.push(type);
  }
  if (typeof q === 'string' && q.trim()) {
    sql += ` AND (
      case_no LIKE ? OR court LIKE ? OR bench LIKE ?
      OR type LIKE ? OR issue LIKE ? OR result LIKE ? OR notes LIKE ?
    )`;
    const like = `%${q.trim()}%`;
    for (let i = 0; i < 7; i++) params.push(like);
  }

  sql += ' ORDER BY COALESCE(start_date, "") DESC, created_at DESC';

  const rows = db.prepare(sql).all(...params) as Case[];
  res.json(rows);
});


// GET /api/cases/:id - 단일 조회 (관련 문서·이벤트 포함)
casesRouter.get('/:id', (req, res) => {
  const id = req.params.id;
  const caseRow = db.prepare('SELECT * FROM cases WHERE id = ?').get(id) as Case | undefined;
  if (!caseRow) return res.status(404).json({ error: 'not found' });

  const documents = db.prepare('SELECT * FROM documents WHERE case_id = ? ORDER BY uploaded_at DESC').all(id);
  const events    = db.prepare('SELECT * FROM events    WHERE case_id = ? ORDER BY event_date DESC').all(id);

  res.json({ ...caseRow, documents, events });
});


// POST /api/cases - 생성
casesRouter.post('/', (req, res) => {
  const input = req.body as CaseInput;

  if (!input.case_no || !input.case_no.trim()) {
    return res.status(400).json({ error: '사건번호(case_no)는 필수입니다.' });
  }

  const id = generateId('c');
  const now = Date.now();

  db.prepare(`
    INSERT INTO cases (
      id, case_no, court, bench, type, status, fee,
      start_date, end_date, issue, result, notes,
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    input.case_no.trim(),
    nullIfEmpty(input.court),
    nullIfEmpty(input.bench),
    nullIfEmpty(input.type),
    input.status || '진행중',
    toNumberOrNull(input.fee),
    nullIfEmpty(input.start_date),
    nullIfEmpty(input.end_date),
    nullIfEmpty(input.issue),
    nullIfEmpty(input.result),
    nullIfEmpty(input.notes),
    now, now
  );

  const created = db.prepare('SELECT * FROM cases WHERE id = ?').get(id);
  res.status(201).json(created);
});


// PATCH /api/cases/:id - 부분 수정
casesRouter.patch('/:id', (req, res) => {
  const id = req.params.id;
  const update = req.body as CaseUpdate;

  const existing = db.prepare('SELECT * FROM cases WHERE id = ?').get(id);
  if (!existing) return res.status(404).json({ error: 'not found' });

  // 수정 가능한 필드만 화이트리스트
  const allowed: (keyof CaseUpdate)[] = [
    'case_no', 'court', 'bench', 'type', 'status', 'fee',
    'start_date', 'end_date', 'issue', 'result', 'notes'
  ];

  const setParts: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in update) {
      setParts.push(`${key} = ?`);
      if (key === 'fee') {
        values.push(toNumberOrNull(update[key]));
      } else {
        values.push(nullIfEmpty(update[key]));
      }
    }
  }

  if (setParts.length === 0) {
    return res.status(400).json({ error: '수정할 필드가 없습니다.' });
  }

  setParts.push('updated_at = ?');
  values.push(Date.now());
  values.push(id);

  db.prepare(`UPDATE cases SET ${setParts.join(', ')} WHERE id = ?`).run(...values);

  const updated = db.prepare('SELECT * FROM cases WHERE id = ?').get(id);
  res.json(updated);
});


// DELETE /api/cases/:id - 삭제 (관련 문서·이벤트도 CASCADE)
casesRouter.delete('/:id', (req, res) => {
  const result = db.prepare('DELETE FROM cases WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ error: 'not found' });
  res.json({ ok: true });
});


// GET /api/cases-meta/types - 등록된 감정 유형 목록 (필터 드롭다운용)
casesRouter.get('/meta/types', (_req, res) => {
  const rows = db.prepare(
    'SELECT DISTINCT type FROM cases WHERE type IS NOT NULL AND type != "" ORDER BY type'
  ).all() as { type: string }[];
  res.json(rows.map(r => r.type));
});
