import { Router, Request, Response } from 'express';
import multer from 'multer';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, generateId } from '../db.js';
import type { CaseDocument } from '../types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '..', '..', '..');
const FILES_DIR = path.join(PROJECT_ROOT, 'files');

if (!fs.existsSync(FILES_DIR)) {
  fs.mkdirSync(FILES_DIR, { recursive: true });
}

// 케이스별 폴더에 저장하되, 파일명 충돌 방지를 위해 랜덤 prefix 부여
const storage = multer.diskStorage({
  destination: (req, _file, cb) => {
    const caseId = req.params.caseId;
    if (!caseId) return cb(new Error('case ID 없음'), '');

    // 케이스 존재 확인 (잘못된 ID로 폴더가 무한정 생기는 것 방지)
    const exists = db.prepare('SELECT id FROM cases WHERE id = ?').get(caseId);
    if (!exists) return cb(new Error('해당 케이스를 찾을 수 없습니다.'), '');

    const dir = path.join(FILES_DIR, caseId);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (_req, file, cb) => {
    // 한글 파일명이 깨질 수 있어 latin1 → utf8 변환
    const original = Buffer.from(file.originalname, 'latin1').toString('utf8');
    const ext = path.extname(original);
    const base = path.basename(original, ext).slice(0, 50);
    const stamp = Date.now().toString(36);
    cb(null, `${stamp}_${base}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }   // 100MB 제한
});

export const docsRouter = Router({ mergeParams: true });


// POST /api/cases/:caseId/documents - 파일 업로드 (다중 가능)
docsRouter.post('/:caseId/documents', upload.array('files', 20), (req: Request, res: Response) => {
  const caseId = req.params.caseId;
  const files = req.files as Express.Multer.File[] | undefined;

  if (!files || files.length === 0) {
    return res.status(400).json({ error: '업로드된 파일이 없습니다.' });
  }

  const docType = (req.body.doc_type as string) || null;
  const notes   = (req.body.notes as string) || null;
  const now = Date.now();

  const insert = db.prepare(`
    INSERT INTO documents (id, case_id, filename, stored_path, doc_type, size_bytes, mime_type, notes, uploaded_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const inserted: CaseDocument[] = [];
  const insertMany = db.transaction((files: Express.Multer.File[]) => {
    for (const f of files) {
      const id = generateId('d');
      const filename = Buffer.from(f.originalname, 'latin1').toString('utf8');
      const storedPath = path.relative(PROJECT_ROOT, f.path).replace(/\\/g, '/');

      insert.run(id, caseId, filename, storedPath, docType, f.size, f.mimetype, notes, now);
      inserted.push({
        id, case_id: caseId, filename, stored_path: storedPath,
        doc_type: docType, size_bytes: f.size, mime_type: f.mimetype,
        notes, uploaded_at: now
      });
    }
  });
  insertMany(files);

  res.status(201).json(inserted);
});


// GET /api/cases/:caseId/documents - 케이스의 문서 목록
docsRouter.get('/:caseId/documents', (req, res) => {
  const rows = db.prepare(
    'SELECT * FROM documents WHERE case_id = ? ORDER BY uploaded_at DESC'
  ).all(req.params.caseId);
  res.json(rows);
});


// GET /api/documents/:docId/download - 파일 다운로드
docsRouter.get('/documents/:docId/download', (req, res) => {
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.docId) as CaseDocument | undefined;
  if (!doc) return res.status(404).json({ error: 'not found' });

  const fullPath = path.join(PROJECT_ROOT, doc.stored_path);
  if (!fs.existsSync(fullPath)) return res.status(404).json({ error: '파일이 디스크에 없습니다.' });

  res.download(fullPath, doc.filename);
});


// DELETE /api/documents/:docId - 문서 삭제 (DB + 디스크)
docsRouter.delete('/documents/:docId', (req, res) => {
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.docId) as CaseDocument | undefined;
  if (!doc) return res.status(404).json({ error: 'not found' });

  const fullPath = path.join(PROJECT_ROOT, doc.stored_path);
  try { if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath); } catch (e) { console.error(e); }

  db.prepare('DELETE FROM documents WHERE id = ?').run(doc.id);
  res.json({ ok: true });
});
