-- 법원 감정 케이스 관리 DB 스키마
-- SQLite는 외래키를 기본 비활성화하므로 db.ts에서 PRAGMA로 활성화함

CREATE TABLE IF NOT EXISTS cases (
  id           TEXT PRIMARY KEY,         -- UUID 또는 c_타임스탬프 형식
  case_no      TEXT NOT NULL,             -- 사건번호 (예: 2024가합12345)
  court        TEXT,                      -- 법원
  bench        TEXT,                      -- 재판부
  type         TEXT,                      -- 감정 유형 (건축/의료/측량/기타)
  status       TEXT NOT NULL DEFAULT '진행중',  -- 진행상태
  fee          INTEGER,                   -- 감정료 (원 단위)
  start_date   TEXT,                      -- 착수일 (YYYY-MM-DD)
  end_date     TEXT,                      -- 제출/완료일
  issue        TEXT,                      -- 감정 쟁점
  result       TEXT,                      -- 결과 요약
  notes        TEXT,                      -- 비고
  created_at   INTEGER NOT NULL,          -- Unix epoch (ms)
  updated_at   INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cases_case_no ON cases(case_no);
CREATE INDEX IF NOT EXISTS idx_cases_status  ON cases(status);
CREATE INDEX IF NOT EXISTS idx_cases_type    ON cases(type);
CREATE INDEX IF NOT EXISTS idx_cases_start   ON cases(start_date);


CREATE TABLE IF NOT EXISTS documents (
  id           TEXT PRIMARY KEY,
  case_id      TEXT NOT NULL,
  filename     TEXT NOT NULL,             -- 원본 파일명 (사용자가 본 이름)
  stored_path  TEXT NOT NULL,             -- 디스크 저장 경로 (files/<case_id>/<random>)
  doc_type     TEXT,                      -- 문서 유형 (감정신청서/감정서/판결문/사진/도면/기타)
  size_bytes   INTEGER,
  mime_type    TEXT,
  notes        TEXT,
  uploaded_at  INTEGER NOT NULL,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_docs_case_id ON documents(case_id);


CREATE TABLE IF NOT EXISTS events (
  id           TEXT PRIMARY KEY,
  case_id      TEXT NOT NULL,
  event_date   TEXT NOT NULL,             -- YYYY-MM-DD
  event_type   TEXT,                      -- 감정신청/현장조사/감정서제출/판결 등
  description  TEXT,
  created_at   INTEGER NOT NULL,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_events_case_id ON events(case_id);
CREATE INDEX IF NOT EXISTS idx_events_date    ON events(event_date);
