# 실행 가이드 (처음부터 끝까지)

## 1단계 — Node.js 설치

이미 설치되어 있다면 건너뛰셔도 됩니다.
- https://nodejs.org → LTS 버전 다운로드 (v18 이상)
- 설치 후 터미널/PowerShell에서 확인:
  ```
  node --version
  npm --version
  ```

## 2단계 — 프로젝트 폴더 준비

이 프로젝트 압축을 풀어 원하는 위치에 배치합니다. 예:
- Windows: `D:\projects\court-cases\`
- Mac: `~/projects/court-cases/`

## 3단계 — 의존성 설치

터미널에서 `server` 폴더로 이동:
```
cd court-cases/server
npm install
```

이 과정에서 `better-sqlite3`가 빌드됩니다 (1~2분 소요).
※ Windows에서 빌드 오류 시: `npm install --global windows-build-tools` 실행 후 재시도

## 4단계 — 실행

같은 폴더에서:
```
npm run dev
```

성공 시 다음과 같은 메시지가 나옵니다:
```
[db] connected: .../court-cases/db/cases.db
[server] listening on http://localhost:3000
[server] external: http://<this-machine-ip>:3000
```

## 5단계 — 브라우저 접속

http://localhost:3000

첫 화면에서 "+ 새 케이스"를 눌러 등록을 시작합니다.

---

## 외부 접속 설정 (Tailscale)

평소 PC가 켜져 있어야 외부에서 접속 가능합니다.

1. **Tailscale 가입**
   https://tailscale.com → "Get started" (무료 플랜으로 충분)

2. **서버 PC에 설치**
   다운로드 후 본인 계정으로 로그인

3. **휴대폰/노트북에도 설치**
   같은 계정으로 로그인 → 서로 인식됨

4. **Tailscale IP 확인**
   서버 PC에서 Tailscale 앱을 열면 IP 표시 (예: `100.64.12.34`)

5. **외부 디바이스에서 접속**
   `http://100.64.12.34:3000`

Tailscale은 본인 계정 디바이스끼리만 묶는 사설 네트워크라 인터넷에 노출되지 않습니다. 비밀번호 추가 보안은 추후 nginx + basic auth로 추가 가능합니다.

---

## 백업

다음 두 폴더만 정기적으로 백업하면 모든 데이터가 보존됩니다:
- `db/cases.db` — 모든 케이스 메타데이터
- `files/` — 모든 첨부 문서

외장하드, 클라우드 동기화 폴더(OneDrive, Dropbox 등) 또는 별도 백업 스크립트로 자동화할 수 있습니다.

---

## 자주 쓰는 명령

```
npm run dev        # 개발 모드 (코드 변경 시 자동 재시작)
npm run build      # TypeScript 컴파일 → dist/ 폴더에 JS 생성
npm run start      # 프로덕션 모드 (빌드된 코드 실행)
```

---

## 문제 해결

**포트 3000이 이미 사용 중**
다른 프로그램이 3000을 쓰는 경우. 다음 명령으로 다른 포트 사용:
```
PORT=4000 npm run dev      # Mac/Linux
$env:PORT=4000; npm run dev   # Windows PowerShell
```

**better-sqlite3 빌드 오류**
- Windows: Visual Studio Build Tools 설치 필요
- Mac: Xcode Command Line Tools (`xcode-select --install`)

**한글 파일명이 깨져 보임**
서버 코드(`docs.ts`)에 latin1 → utf8 변환 처리가 들어 있습니다. 브라우저 캐시 새로고침 후 재시도.
