# 법원 감정 케이스 관리 시스템

법원 감정 진행 케이스를 등록·검색·관리하는 로컬 웹 애플리케이션입니다.
케이스 메타데이터는 SQLite DB에, 첨부 문서(감정서, 판결문, 도면 등)는 로컬 파일 시스템에 저장합니다.

## 폴더 구조

```
court-cases/
├── server/          # Node.js + Express + TypeScript 백엔드
│   ├── src/
│   │   ├── index.ts       # 서버 진입점
│   │   ├── db.ts          # DB 연결 및 초기화
│   │   ├── routes/
│   │   │   ├── cases.ts   # 케이스 CRUD API
│   │   │   └── docs.ts    # 문서 업로드/다운로드 API
│   │   └── types.ts       # 공유 타입 정의
│   ├── package.json
│   └── tsconfig.json
├── client/          # 정적 웹 프론트엔드 (HTML/CSS/JS)
│   └── index.html
├── db/              # SQLite 데이터베이스 파일 위치
│   └── cases.db     # (자동 생성)
├── files/           # 첨부 문서 저장 위치
│   └── <case_id>/   # (케이스별 폴더 자동 생성)
└── scripts/
    └── schema.sql   # DB 스키마 정의
```

## 빠른 시작

### 1. Node.js 설치 확인
```bash
node --version    # v18 이상 권장
npm --version
```

### 2. 서버 의존성 설치
```bash
cd server
npm install
```

### 3. 개발 모드로 실행
```bash
npm run dev
```

처음 실행 시 `db/cases.db`가 자동 생성되고 스키마가 적용됩니다.

### 4. 브라우저 접속
http://localhost:3000

## 외부 접속 (Tailscale)

평소엔 로컬에서만 동작하지만, 외부에서 접근하려면:

1. https://tailscale.com 에서 무료 계정 생성
2. 본인 PC와 휴대폰/노트북에 Tailscale 설치 및 같은 계정으로 로그인
3. 서버 PC의 Tailscale IP 확인 (예: `100.x.x.x`)
4. 외부 디바이스에서 `http://100.x.x.x:3000` 접속

Tailscale은 본인 디바이스끼리만 묶는 사설 네트워크라 인터넷에 노출되지 않습니다.

## 주요 기능

- 케이스 등록·수정·삭제
- 사건번호·법원·쟁점·결과 통합 검색
- 진행상태·감정 유형 필터
- 케이스별 첨부문서 업로드·다운로드 (PDF, 한글, 이미지 등)
- 진행 이력(events) 기록

## 향후 클라우드 이전 시 변경 포인트

| 현재 | 클라우드 이전 시 |
|------|-----------------|
| SQLite (`db/cases.db`) | PostgreSQL |
| 로컬 파일 (`files/`) | AWS S3 또는 Cloudflare R2 |
| `npm run dev` | Railway·Render·Fly.io 배포 |

`server/src/db.ts`, `server/src/routes/docs.ts`만 수정하면 되고, 클라이언트 코드는 그대로입니다.
