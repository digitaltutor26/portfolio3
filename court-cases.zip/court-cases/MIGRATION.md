# 클라우드 이전 체크리스트

로컬 운영이 안정화된 뒤 클라우드로 옮길 때 참고하시는 문서입니다.
**현재 코드는 마이그레이션을 염두에 두고 작성되어, 변경 포인트가 제한적입니다.**

## 변경이 필요한 부분 (3곳)

### 1. DB: SQLite → PostgreSQL

**현재** `server/src/db.ts`
```ts
import Database from 'better-sqlite3';
export const db = new Database(DB_PATH);
```

**이전 후**
```ts
import { Pool } from 'pg';
export const db = new Pool({ connectionString: process.env.DATABASE_URL });
```

쿼리 호출 방식이 동기 → 비동기로 바뀌므로 `routes/cases.ts`의 모든 `db.prepare(...).run/get/all`을
`await db.query(...)`로 일괄 변경합니다. 쿼리 SQL 문법은 거의 동일합니다.

**스키마 변경**
- `INTEGER NOT NULL` (created_at, updated_at) → `BIGINT NOT NULL`
- `?` 파라미터 → `$1, $2, ...`

### 2. 파일 저장: 로컬 → S3 (또는 R2)

**현재** `server/src/routes/docs.ts`
```ts
const storage = multer.diskStorage({ ... });
res.download(fullPath, doc.filename);
```

**이전 후**
```ts
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import multerS3 from 'multer-s3';

const storage = multerS3({
  s3: new S3Client({ region: 'ap-northeast-2' }),
  bucket: process.env.S3_BUCKET,
  key: (req, file, cb) => cb(null, `${req.params.caseId}/${Date.now()}_${file.originalname}`),
});

// 다운로드는 presigned URL 발급
const url = await getSignedUrl(s3, new GetObjectCommand({ Bucket, Key }), { expiresIn: 300 });
res.redirect(url);
```

**Cloudflare R2 추천 이유**: AWS S3 API와 호환되는데 egress(다운로드) 비용이 무료입니다.

### 3. 환경 변수 분리

`.env` 파일 생성:
```
DATABASE_URL=postgresql://user:pass@host:5432/court_cases
S3_BUCKET=your-bucket-name
S3_ENDPOINT=https://...r2.cloudflarestorage.com   # R2 사용 시
PORT=3000
```

`server/src/index.ts`에 추가:
```ts
import 'dotenv/config';
```

## 변경이 필요 없는 부분

다음은 그대로 동작합니다:
- `server/src/types.ts` — 타입 정의 그대로
- `server/src/routes/cases.ts` — SQL 쿼리 호출 방식만 비동기로
- `client/index.html` — 클라이언트 코드 전체 (API URL만 환경에 따라 조정)

## 호스팅 선택지

### Railway (가장 쉬움)
- GitHub 연동 → 자동 배포
- PostgreSQL 애드온 1클릭 추가
- 월 $5 크레딧 무료, 추가분 종량제

### Render
- 무료 플랜에서 PostgreSQL 90일 제한 있음
- 정적 사이트는 무료

### Fly.io
- 무료 티어 관대함 (앱 3개 + Postgres)
- 학습 곡선 약간 있음

### 자체 VPS (Vultr, Linode)
- 월 $5~ 고정 비용
- 직접 nginx, systemd 설정 필요

## 데이터 마이그레이션

**SQLite → PostgreSQL**
```bash
# pgloader 사용 (가장 간단)
pgloader sqlite:///path/to/cases.db postgresql://user:pass@host/court_cases
```

**로컬 파일 → S3/R2**
```bash
# AWS CLI
aws s3 sync ./files s3://your-bucket/files

# rclone (R2 추천)
rclone copy ./files r2:your-bucket/files
```

## 보안 추가 권장사항 (외부 공개 시)

1. **인증**: 단순한 환경이라도 Basic Auth 또는 JWT 도입
2. **HTTPS**: Let's Encrypt 자동 발급 (Caddy 사용 시 자동)
3. **백업**: PostgreSQL 자동 백업 (Railway·Render 모두 옵션 제공)
4. **모니터링**: Sentry 무료 플랜으로 에러 트래킹

## 단계적 이전 권장 순서

1. 로컬에서 케이스 50건 이상 누적 → 실제 사용 패턴 파악
2. 데이터 export 기능부터 추가 (`/api/cases/export.json`)
3. PostgreSQL로 DB만 먼저 이전 (파일은 로컬 유지)
4. 잘 동작하면 파일도 S3로 이전
5. 마지막으로 호스팅 이전
